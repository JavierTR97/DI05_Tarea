package main.java.app;

import java.util.List;

public class Album {
    private String titulo;
    private List<Pista> pistas;

    public Album(String titulo, List<Pista> pistas) {
        this.titulo = titulo;
        this.pistas = pistas;
    }

    public String getTitulo() {
        return titulo;
    }

    public List<Pista> getPistas() {
        return pistas;
    }
}
