package main.java.app;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import main.java.app.Database;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ClientesController implements Initializable {

    @FXML
    private ListView<String> clientesListView;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarClientesDesdeBD();
    }

    protected void cargarClientesDesdeBD() {
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT FirstName || ' ' || LastName AS FullName FROM customers ORDER BY LastName")) {

            while (rs.next()) {
                String nombre = rs.getString("FullName");
                clientesListView.getItems().add(nombre);
            }

        } catch (SQLException e) {
            System.err.println("Error al acceder a la base de datos:");
            e.printStackTrace();
        }
    }
}
