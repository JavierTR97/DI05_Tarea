package main.java.app;

public class Pista {
    private String nombre;

    public Pista(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
