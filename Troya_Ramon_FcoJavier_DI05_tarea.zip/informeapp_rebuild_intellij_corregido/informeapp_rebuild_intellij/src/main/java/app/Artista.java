package main.java.app;

import java.util.List;

public class Artista {
    private int id;
    private String nombre;
    private List<Album> albums;

    public Artista(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Album> getAlbums() {
        return albums;
    }

    public void setAlbums(List<Album> albums) {
        this.albums = albums;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
