package main.java.app;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.stage.Modality;

import java.io.IOException;

public class MainController {

    @FXML
    private Button btnClientes;

    @FXML
    private Button btnArtistas;

    @FXML
    private Button btnSalir;

    @FXML
    public void initialize() {
        btnClientes.setOnAction(e -> mostrarInformeClientes());
        btnArtistas.setOnAction(e -> mostrarInformeArtistas());
        btnSalir.setOnAction(e -> System.exit(0));
    }

    private void mostrarInformeClientes() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/clientes_view.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Informe de Clientes");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarInformeArtistas() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/artistas_view.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Informe de Artistas");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
