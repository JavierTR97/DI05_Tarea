package main.java.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static final String URL = "jdbc:sqlite:C:/Users/javic/Downloads/informeapp_rebuild_intellij_corregido/chinook.db";

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(URL);
        System.out.println("✅ Conectado a la base de datos en: " + URL);
        return conn;
    }

}
