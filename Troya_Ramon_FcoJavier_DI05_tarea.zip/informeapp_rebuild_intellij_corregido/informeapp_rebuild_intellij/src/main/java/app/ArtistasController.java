package main.java.app;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class ArtistasController implements Initializable {

    @FXML
    private ImageView logoEmpresa;

    @FXML
    private ListView<String> artistasListView;

    @FXML
    private Label nombreArtistaLabel;

    @FXML
    private TextArea informeTextArea;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Cargar logo
        try {
            Image logo = new Image(getClass().getResourceAsStream("logo.png"));
            logoEmpresa.setImage(logo);
        } catch (Exception e) {
            System.err.println("⚠️ No se pudo cargar el logo.");
        }

        // Cargar artistas
        cargarArtistasDesdeBD();

        // Listener de selección
        artistasListView.setOnMouseClicked(event -> {
            String artistaSeleccionado = artistasListView.getSelectionModel().getSelectedItem();
            if (artistaSeleccionado != null) {
                generarInformeArtista(artistaSeleccionado);
            }
        });
    }

    private void cargarArtistasDesdeBD() {
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT Name FROM artists ORDER BY Name")) {

            while (rs.next()) {
                artistasListView.getItems().add(rs.getString("Name"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Error al cargar artistas:");
            e.printStackTrace();
        }
    }

    private void generarInformeArtista(String nombreArtista) {
        StringBuilder informe = new StringBuilder();
        nombreArtistaLabel.setText("Artista: " + nombreArtista);

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT albums.Title AS AlbumTitle, tracks.Name AS TrackName " +
                             "FROM artists " +
                             "JOIN albums ON artists.ArtistId = albums.ArtistId " +
                             "JOIN tracks ON albums.AlbumId = tracks.AlbumId " +
                             "WHERE artists.Name = ? " +
                             "ORDER BY albums.Title, tracks.Name")) {

            ps.setString(1, nombreArtista);
            ResultSet rs = ps.executeQuery();

            String albumActual = "";
            while (rs.next()) {
                String album = rs.getString("AlbumTitle");
                String track = rs.getString("TrackName");

                if (!album.equals(albumActual)) {
                    if (!albumActual.isEmpty()) informe.append("\n");
                    informe.append("📀 Álbum: ").append(album).append("\n");
                    albumActual = album;
                }
                informe.append("    🎶 ").append(track).append("\n");
            }

            if (informe.length() == 0) {
                informeTextArea.setText("Este artista no tiene álbumes registrados.");
            } else {
                informeTextArea.setText(informe.toString());
            }

        } catch (SQLException e) {
            informeTextArea.setText("❌ Error al generar el informe.");
            e.printStackTrace();
        }
    }
}
